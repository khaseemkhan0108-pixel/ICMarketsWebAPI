﻿using ICMarkets.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICMarkets.Application.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<BlockchainData> BlockchainRepository { get; }
        Task<int> CompleteAsync(); 
    }
}
