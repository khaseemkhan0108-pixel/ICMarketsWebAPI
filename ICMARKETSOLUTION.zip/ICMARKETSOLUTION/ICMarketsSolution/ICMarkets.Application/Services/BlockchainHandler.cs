﻿using ICMarkets.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ICMarkets.Domain;

namespace ICMarkets.Application.Services
{
    public class BlockchainHandler : IBlockchainHandler
    {
        private readonly IBlockchainService _service;
        private readonly IUnitOfWork _unitOfWork;

        private readonly Dictionary<string, string> _coinUrls = new()
    {
        { "ETH", "https://api.blockcypher.com/v1/eth/main" },
        { "BTC", "https://api.blockcypher.com/v1/btc/main" },
        { "LTC", "https://api.blockcypher.com/v1/ltc/main" },
        { "DASH", "https://api.blockcypher.com/v1/dash/main" }
    };

        public BlockchainHandler(IBlockchainService service, IUnitOfWork unitOfWork)
        {
            _service = service;
            _unitOfWork = unitOfWork;
        }

        public async Task FetchAndStoreAllAsync()
        {
            foreach (var pair in _coinUrls)
            {
                var data = await _service.FetchDataAsync(pair.Key, pair.Value);
                await _unitOfWork.BlockchainRepository.AddAsync(data);
            }
            await _unitOfWork.CompleteAsync();
        }
    }
}
