﻿namespace ICMarkets.Domain
{
    public class Class1
    {

    }
}