﻿using ICMarkets.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ICMarkets.Application.Interfaces;

namespace ICMarkets.Infrastructure.Services
{
    public class BlockchainService : IBlockchainService
    {
        private readonly HttpClient _httpClient;

        public BlockchainService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<BlockchainData> FetchDataAsync(string coinType, string url)
        {
            var json = await _httpClient.GetStringAsync(url);
            return new BlockchainData
            {
                CoinType = coinType,
                JsonData = json,
                CreatedAt = DateTime.UtcNow
            };
        }
    }
}
