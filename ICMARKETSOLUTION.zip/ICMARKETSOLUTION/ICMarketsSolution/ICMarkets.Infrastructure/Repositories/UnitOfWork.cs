﻿using ICMarkets.Application.Interfaces;
using ICMarkets.Domain;
using ICMarkets.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICMarkets.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;
        private IRepository<BlockchainData>? _blockchainRepository;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
        }

        public IRepository<BlockchainData> BlockchainRepository =>
            _blockchainRepository ??= new Repository<BlockchainData>(_context);

        public async Task<int> CompleteAsync() => await _context.SaveChangesAsync();

        public void Dispose() => _context.Dispose();
    }
}
