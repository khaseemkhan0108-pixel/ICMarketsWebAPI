﻿namespace ICMarkets.Infrastructure
{
    public class Class1
    {

    }
}