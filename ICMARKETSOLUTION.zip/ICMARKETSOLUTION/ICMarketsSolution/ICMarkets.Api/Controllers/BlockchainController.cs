﻿using ICMarkets.Application.Interfaces;
using ICMarkets.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace ICMarkets.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BlockchainController : ControllerBase
    {
        private readonly IUnitOfWork _uow;
        private readonly IBlockchainHandler _handler;

        public BlockchainController(IUnitOfWork uow, IBlockchainHandler handler)
        {
            _uow = uow;
            _handler = handler;
        }

        [HttpPost("fetch")]
        public async Task<IActionResult> FetchAndStore()
        {
            await _handler.FetchAndStoreAllAsync();
            return Ok("Blockchain data fetched and stored successfully.");
        }

        [HttpGet("history")]
        public async Task<IActionResult> GetHistory()
        {
            var data = await _uow.BlockchainRepository.GetAllAsync();
            return Ok(data.OrderByDescending(x => x.CreatedAt));
        }
    }
}
